let answerUrl;
let chapterData;

function fetchChapterData() {
  return new Promise((resolve, reject) => {
    if (chapterData) return resolve(chapterData); // Evita richieste duplicate
    chrome.runtime.sendMessage({ type: "load", url: answerUrl }, (data) => {
      console.table(data);
      if (data) {
        chapterData = data;
        resolve(data);
      } else {
        reject(new Error("Failed to fetch chapter data."));
      }
    });
  });
}

function matchText(textA, textB) {
  const replaceRegex = /[^\w]/gi;
  textA = textA.replace(replaceRegex, "").toLowerCase();
  textB = textB.replace(replaceRegex, "").toLowerCase();
  return textA === textB;
}

function findEntryByQuestion(inputText, chapterData) {
  for (let entry of chapterData) {
    if (matchText(inputText, entry.question)) {
      return entry;
    }
  }
  return null;
}

async function handlePromptQuestion() {
  const inputText = prompt("Inserisci la domanda:")?.trim();
  if (!inputText) return;

  try {
    const data = await fetchChapterData();
    const entry = findEntryByQuestion(inputText, data);
    if (!entry) {
      alert("Domanda non trovata nei dati.");
      return;
    }

    alert(`Risposta(e) corretta(e):\n- ${entry.answers.join("\n- ")}`);
  } catch (error) {
    console.error("Errore durante il fetch dei dati del capitolo:", error);
    alert("Errore nel recupero dei dati.");
  }
}

window.addEventListener("keydown", event => {
  if (event.key == "a") {
    handlePromptQuestion();
  } else if (event.key == "n") {
    document.getElementById("next")?.click();
  } else if (event.key == "p") {
    chrome.storage.local.get(["lastUrl"], result => {
      answerUrl = "https://itexamanswers.net/ccna-1-v7-0-final-exam-answers-full-introduction-to-networks.html";
      chrome.storage.local.set({ lastUrl: answerUrl });
      fetchChapterData(); // Preload
    });
  }
});
